# NAME

e - The great new e!

# VERSION

Version 0.01

# SYNOPSIS

Quick summary of what the module does.

Perhaps a little code snippet.

    use e;

    my $foo = e->new();
    ...

# EXPORT

A list of functions that can be exported.  You can delete this section
if you don't export anything, such as for a purely object-oriented module.

# SUBROUTINES/METHODS

## function1

## function2

# AUTHOR

tim Potapov, `<tim.potapov[AT]gmail.com>`

# BUGS

Please report any bugs or feature requests to `bug-e at rt.cpan.org`, or through
the web interface at [https://rt.cpan.org/NoAuth/ReportBug.html?Queue=e](https://rt.cpan.org/NoAuth/ReportBug.html?Queue=e).  I will be notified, and then you'll
automatically be notified of progress on your bug as I make changes.

# SUPPORT

You can find documentation for this module with the perldoc command.

    perldoc e

You can also look for information at:

- RT: CPAN's request tracker (report bugs here)

    [https://rt.cpan.org/NoAuth/Bugs.html?Dist=e](https://rt.cpan.org/NoAuth/Bugs.html?Dist=e)

- CPAN Ratings

    [https://cpanratings.perl.org/d/e](https://cpanratings.perl.org/d/e)

- Search CPAN

    [https://metacpan.org/release/e](https://metacpan.org/release/e)

# ACKNOWLEDGEMENTS

# LICENSE AND COPYRIGHT

This software is Copyright (c) 2024 by tim Potapov.

This is free software, licensed under:

    The Artistic License 2.0 (GPL Compatible)
